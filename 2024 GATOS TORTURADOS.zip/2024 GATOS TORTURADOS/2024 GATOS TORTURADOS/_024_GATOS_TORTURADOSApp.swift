//
//  _024_GATOS_TORTURADOSApp.swift
//  2024 GATOS TORTURADOS
//
//  Created by MAC32 on 25/11/24.
//

import SwiftUI

@main
struct _024_GATOS_TORTURADOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
            Inicio()
            Pantalla_de_inicio()
            
        }
    }
}
