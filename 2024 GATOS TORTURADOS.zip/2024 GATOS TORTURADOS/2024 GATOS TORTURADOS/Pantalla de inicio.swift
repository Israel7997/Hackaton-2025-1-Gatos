//
//  Pantalla de inicio.swift
//  2024 GATOS TORTURADOS
//
//  Created by MAC32 on 25/11/24.
//

import SwiftUI

struct Pantalla_de_inicio: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Pantalla_de_inicio()
}
