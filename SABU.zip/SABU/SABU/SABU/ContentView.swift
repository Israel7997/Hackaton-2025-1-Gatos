//
//  ContentView.swift
//  SABU
//
//  Created by CEDAM30 on 25/11/24.
//

import SwiftUI
//import SwiftData

struct ContentView: View {
    @State private var showMenu = false
    @State private var selectedTab = 0
    @AppStorage("isDarkModeOn") private var isDarkModeOn = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                TabView(selection: $selectedTab) {
                    Text("Inicio")
                        .tag(0)
                    
                    Text("Medicina General")
                        .tag(1)
                    
                    Text("Salud Mental")
                        .tag(2)
                    
                    Text("Nutrición")
                        .tag(3)
                    
                    Text("Perfil")
                        .tag(4)
                }
                
                ContentSideMenuView(isShowing: $showMenu, selectedTab: $selectedTab)
            }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(action: {
                        showMenu.toggle()
                    }, label: {
                        Image(systemName: "line.3.horizontal")
                            .foregroundColor(isDarkModeOn ? .white : .gray)
                    })
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
