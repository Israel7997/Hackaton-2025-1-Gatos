//
//  HeaderView.swift
//  SABU
//
//  Created by CEDAM30 on 25/11/24.
//

import SwiftUI

struct HeaderView: View {
    var body: some View {
        HStack {
            Image("goyo")
                .resizable()
                .foregroundColor(.white)
                .frame(width: 48, height: 48)
                .background(.blue)
                .clipShape(Circle())
                .padding(.vertical)
            
            VStack(alignment: .leading, spacing: 6.0) {
                Text("Goyo Acatlan")
                    .font(.subheadline)
                
                Text("goyito@gmail.com")
                    .font(.footnote)
            }
            
        }
    }
}

#Preview {
    HeaderView()
}
