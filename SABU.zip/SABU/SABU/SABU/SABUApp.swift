//
//  SABUApp.swift
//  SABU
//
//  Created by CEDAM30 on 25/11/24.
//

import SwiftUI
import SwiftData

@main
struct SABUApp: App {
    @AppStorage("isDarkModeOn") private var isDarkModeOn = false
        var body: some Scene {
            WindowGroup {
                ContentView()
                    .preferredColorScheme(isDarkModeOn ? .dark : .light)
            }
        }
}
